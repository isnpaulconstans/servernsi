#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 23:13:46 2020

@author: manu
"""

annee = "2019-2020/"
with open(annee + "adresses_mail.csv", "r") as src, \
     open(annee + "users.csv", "w") as dest:
    src.readline()
    for ligne in src:
        _, nom, prenom, _, date = ligne.strip().split(',')
        nom = nom.replace('"', '').strip().title()
        prenom = prenom.replace('"', '').strip().title()
        passw = nom.lower()[0] + prenom.lower()[0] + date.replace('"', '')
        dest.write(','.join([nom, prenom, '1NSI', passw])+'\n')
